﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnBlock : MonoBehaviour
{
    public PlayerBehavior player;

    private void Awake()
    {
        if (FindObjectOfType<PlayerBehavior>())
        {
            player = FindObjectOfType<PlayerBehavior>();
            player.transform.position = gameObject.transform.position;

        }
        else
        {
            // TODO: Get the camera to follow the player when created through code
            Instantiate(player, gameObject.transform.position, Quaternion.identity);
        }
    }
}
