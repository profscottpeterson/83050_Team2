﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrackPlatform : MonoBehaviour
{
    public Transform[] wayPoints;

    public bool fallsOff;
    public int currentWayPoint;
    public float speed;

    private Transform targetWayPoint;
    private bool playerTouched = false;
    private bool reverse;

    // Start is called before the first frame update
    void Start()
    {
            
    }

    private void FixedUpdate()
    {
        if (currentWayPoint < this.wayPoints.Length && playerTouched)
        {
            if (targetWayPoint == null)
            {
                targetWayPoint = wayPoints[currentWayPoint];
            }
            
            Travel();        
        }
    }

    private void Travel()
    {
        transform.position = Vector3.MoveTowards(transform.position, targetWayPoint.position, speed * .05f);

        if (transform.position == targetWayPoint.position)
        {
            // Going Forwards
            if (!reverse)
            {
                currentWayPoint++;

                if (currentWayPoint == this.wayPoints.Length)
                {
                    if (fallsOff)
                    {
                        gameObject.AddComponent<Rigidbody2D>();
                        Destroy(this);
                    }
                    else
                    {
                        reverse = true;
                        currentWayPoint -= 2;
                        targetWayPoint = wayPoints[currentWayPoint];
                    }
                }
                else
                {
                    targetWayPoint = wayPoints[currentWayPoint];
                }
            }
            else if (reverse)
            {
                currentWayPoint--;

                if (currentWayPoint == -1)
                {
                    reverse = false;
                    currentWayPoint += 2;
                    targetWayPoint = wayPoints[currentWayPoint];
                }
                else
                {
                    targetWayPoint = wayPoints[currentWayPoint];
                }

            }

        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            playerTouched = true;
            collision.transform.parent = transform.transform;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            collision.transform.parent = null;
        }
    }
}
