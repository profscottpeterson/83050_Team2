﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pickup : MonoBehaviour
{
    private PlayerBehavior player;

    // H = health, J = Double Jump
    public char pickupAbility;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Grab the gameObject that's colliding with the pickup object
        var collider = collision.gameObject;

        // If the gameObject is a player
        if (collider.CompareTag("Player"))
        {
            // Player Reference
            player = collider.GetComponent<PlayerBehavior>();

            // If the pick up is set to health
            if (pickupAbility == 'H')
            {
                // If the player is lower than max hp
                if (player.currentHealth < player.maxHealth)
                {
                    Destroy(this.gameObject);
                    player.ChangeHealth(1);
                }
            }
            // If the pick up is set to double jump
            else if (pickupAbility == 'J')
            {
                player.DoubleJump(gameObject);
            }
        }
    }
}
