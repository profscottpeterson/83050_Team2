﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIElements : MonoBehaviour
{
    public static UIElements instance { get; private set; }
    public Text uiHealth;
    public Text uiTimer;
    public Text uiScore;
    public float totalTime = 300.0f;

    private float currentTime;
    void Awake()
    {
        instance = this;

        uiTimer.text = totalTime.ToString();
    }

    public void UpdateHealth(int value)
    {
        uiHealth.text = value.ToString();
    }

    public void UpdateScore(int value)
    {
        uiScore.text = (int.Parse(uiScore.text) + value).ToString();
    }

    public void IncrementTime()
    {
        totalTime = totalTime - Time.deltaTime;

        uiTimer.text = Mathf.Round(totalTime).ToString();
    }
}