﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBehavior : MonoBehaviour
{
    // Alive check because the Player was technically killing the same enemy twice
    private bool alive = true;

    Rigidbody2D rbPlayer;
    Transform tr;

    // Player kills
    private void OnTriggerEnter2D(Collider2D collision)
    {
        tr = GetComponent<Transform>();
        PlayerMovement player = collision.gameObject.GetComponent<PlayerMovement>();

        if (player != null && alive == true)
        {
            UIElements.instance.UpdateScore(50);

            player.jumping = true;
            alive = false;

            tr.position -= new Vector3(0, 0.5f, 0);
            tr.localScale -= new Vector3(0, 1, 0);
            BoxCollider2D box = GetComponent<BoxCollider2D>();
            Destroy(box);
            Destroy(this);
        }
    }

    // When the player enters/is in the damage zone
    private void OnCollisionStay2D(Collision2D collision)
    {
        PlayerMovement player = collision.gameObject.GetComponent<PlayerMovement>();

        if (player != null)
        {
            player.ChangeHealth(-1);
        }
    }
}
