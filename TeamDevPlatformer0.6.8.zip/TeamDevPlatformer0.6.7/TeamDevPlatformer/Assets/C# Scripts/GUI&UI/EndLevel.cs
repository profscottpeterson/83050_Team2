﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EndLevel : MonoBehaviour
{
    public short levelToUnlock;

    public Text timeToFinish;
    public Text finalScore;
    public Canvas endUI;

    private void Start()
    {
        endUI.enabled = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        PlayerBehavior player = collision.gameObject.GetComponent<PlayerBehavior>();

        if (player != null)
        {
            endUI.enabled = true;
            timeToFinish.text = UIElements.instance.CalculateTime();
            UIElements.instance.UpdateScore(int.Parse(UIElements.instance.uiTimer.text));
            finalScore.text = UIElements.instance.uiScore.text;
            Destroy(UIElements.instance.gameObject);

            player.GetComponent<Renderer>().enabled = false;
            player.GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);
            WinLevel();
            Destroy(player);
        }
    }

    public void WinLevel()
    {
        PlayerPrefs.SetInt("levelReached", levelToUnlock);
    }
}
