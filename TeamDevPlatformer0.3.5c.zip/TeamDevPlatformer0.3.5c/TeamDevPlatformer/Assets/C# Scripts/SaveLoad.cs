﻿using System.Runtime.Serialization.Formatters.Binary;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SaveLoad : MonoBehaviour
{
    private float totalTime;
    private int uiHealthValue;

    void Start()
    {

    }

    void Update()
    {


    }

    //create SaveGameObject
    private Save CreateSaveGameObject()
    {
        Save save = new Save();
        save.time = totalTime;
        save.health = uiHealthValue;

        return save;
    }


    //Saves the game
    public void SaveGame()
    {
        Save save = CreateSaveGameObject();

        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.persistentDataPath + "/gamesave.save");
        bf.Serialize(file, save);
        file.Close();

        save.time = totalTime;
        save.health = uiHealthValue;
        Debug.Log("Time: " + totalTime);
        Debug.Log("Health: " + uiHealthValue);

        Debug.Log("Game Saved at: " + Application.persistentDataPath);
    }

    public void LoadGame()
    {

    }

}

