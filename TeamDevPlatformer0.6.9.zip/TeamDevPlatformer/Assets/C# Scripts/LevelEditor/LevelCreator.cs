﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelCreator : MonoBehaviour
{
    public Texture2D map;
    public ColorToPrefab[] colorMappings;

    void Start()
    {
        CreateLevel();       
    }

    void CreateLevel()
    {
        for(int x = 0; x < map.width; x++)
        {
            for (int y = 0; y < map.height; y++)
            {
                CreateTile(x, y);
            }
        }
    }

    void CreateTile(int x, int y)
    {
        Color tileColor = map.GetPixel(x, y);

        if (tileColor.a == 0)
        {
            // Transparent
            return;
        }

        foreach(ColorToPrefab colorMapping in colorMappings)
        {
            if (colorMapping.color.Equals(tileColor))
            {
                Vector2 position = new Vector2(x, y);
                Instantiate(colorMapping.prefab, position, Quaternion.identity);
            }
        }
    }
}
