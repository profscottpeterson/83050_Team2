﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HubDoor : MonoBehaviour
{
    public short playOrder;
    public short levelToLoad;
    public bool locked;

    private void OnTriggerStay2D(Collider2D collision)
    {
        PlayerBehavior player = collision.gameObject.GetComponent<PlayerBehavior>();

        if (player != null && Input.GetKeyDown("w") && player.inAir == false && !this.locked)
        {
            Application.LoadLevel(levelToLoad);
        }
    }
}
