﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingPlatform : MonoBehaviour
{
    public bool enableVerticalMovement;
    public bool enableHorizontalMovement;
    public float speed;
    public float distance;
    
    public GameObject Track;

    private bool upToDown = true;
    private bool leftToRight = true;
    private float startingY;
    private float startingX;

    // Start is called before the first frame update
    void Start()
    {
        startingY = gameObject.transform.position.y;
        startingX = gameObject.transform.position.x;

        Debug.Log(speed);

        // TODO: Make sure the platform is connected to a track and will follow the track
    }

    private void FixedUpdate()
    {
        if (enableVerticalMovement)
        {
            if (upToDown)
            {
                if (gameObject.transform.position.y <= startingY + distance)
                {
                    gameObject.transform.position += new Vector3(0, speed * Time.deltaTime, 0);
                }

                if (gameObject.transform.position.y >= startingY + distance)
                {
                    upToDown = false;
                }
            }

            else if (upToDown == false)
            {
                if (gameObject.transform.position.y >= startingY)
                {
                    gameObject.transform.position -= new Vector3(0, speed * Time.deltaTime, 0);
                }
            
                if (gameObject.transform.position.y <= startingY)
                {
                    upToDown = true;
                }
            }
        }

        if (enableHorizontalMovement)
        {
            if (leftToRight)
            {
                if (gameObject.transform.position.x <= startingX + distance)
                {
                    gameObject.transform.position += new Vector3(speed * Time.deltaTime, 0, 0);
                }

                if (gameObject.transform.position.x >= startingX + distance)
                {
                    leftToRight = false;
                }
            }
            else if (leftToRight == false)
            {
                if (gameObject.transform.position.x >= startingX)
                {
                    gameObject.transform.position -= new Vector3(speed * Time.deltaTime, 0, 0);
                }
            
                if (gameObject.transform.position.x <= startingX)
                {
                    leftToRight = true;
                }
            }
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            if (enableVerticalMovement)
            {
                if (upToDown)
                {
                    collision.transform.position += new Vector3(0, speed * Time.deltaTime, 0);
                }
                else if (upToDown == false)
                {
                    collision.transform.position -= new Vector3(0, speed * Time.deltaTime, 0);
                }
            }

            if (enableHorizontalMovement)
            {
                if (leftToRight)
                {
                    collision.transform.position += new Vector3(speed * Time.deltaTime, 0, 0);
                }
                else if (leftToRight == false)
                {
                    collision.transform.position -= new Vector3(speed * Time.deltaTime, 0, 0);
                }
            }
        }
    }
}
