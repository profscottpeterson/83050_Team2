﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float currentSpeed;
    public float runSpeed = 0.08f;
    public float jumpSpeed = 10f;
    public bool inAir = true; // Change this if we spawn the player on the ground
    public int maxHealth = 10;
    public float timeInvincible = 3.0f;
    
    int currentHealth;
    float hMove = 0f;
    bool jumping = false;
    float jumphMove;
    bool isInvincible;
    float invincibleTimer;

    Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        // Set health
        currentHealth = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        hMove = Input.GetAxis("Horizontal");
        if (Input.GetAxis("Jump") > 0 && !inAir)
        {
            // jumping is when the player is obtaining upward velocity
            // inAir is when the player is not on the ground
            jumping = true;
        }
    }

    void FixedUpdate()
    {

        if (jumping)
        {
            rb.velocity = new Vector2(hMove * 15f, jumpSpeed);
            jumping = false;
            jumphMove = hMove;
        }
        else if (inAir)
        {
            if (Mathf.Abs(jumphMove - hMove) > 0.3)
            {
                rb.velocity = new Vector2(hMove * runSpeed * 0.7f, rb.velocity.y);
            }
            else
            {
                rb.velocity = new Vector2(hMove * runSpeed * 1.2f, rb.velocity.y);
            }
        }
        else if (!inAir)
        {
            // Mathf.Clamp(n1, n2, n3)
            rb.velocity = new Vector2(hMove * runSpeed, rb.velocity.y);
        }

        //if (rb.velocity.y < 0)
        //{
        //    inAir = true;
        //}

        //if ((rb.position.x > 8 && rb.velocity.x > 0) || (rb.position.x < -8 && rb.velocity.x < 0))
        //{
        //    rb.velocity = new Vector2(0, rb.velocity.y);
        //}

        // Invincibility
        if (isInvincible)
        {
            // Visibly show invincibilty
            gameObject.GetComponent<Renderer>().enabled = !gameObject.GetComponent<Renderer>().enabled;

            // Minus invincible timer
            invincibleTimer -= Time.deltaTime;

            // When Invincibility is done
            if (invincibleTimer < 0)
            {
                // Disable invincibility
                isInvincible = false;

                // Make sure the character is visible
                gameObject.GetComponent<Renderer>().enabled = true;
            }
        }

        currentSpeed = rb.velocity.x;
    }

    // Update Health Method
    public void ChangeHealth(int amount)
    {
        // If damaged
        if (amount < 0)
        {
            // If invincible then leave method
            if (isInvincible)
            {
                return;
            }

            // Turn invincible on
            isInvincible = true;
            invincibleTimer = timeInvincible;
        }
        
        // Update current health
        currentHealth = Mathf.Clamp(currentHealth + amount, 0, maxHealth);
        
        // Check to see if player is still alive
        if(currentHealth > 0)
        {
            Debug.Log(currentHealth + "/" + maxHealth);
        }
        else
        {
            Debug.Log("Game Over!");
        }
        
       
    }

    // Edge Collision is set to trigger and is on the bottom of the player so the edge collision will fire off the trigger events when the platform class touches it
    // Using the Stay and Exit methods, I got rid of setting the inAir bool to false when someone presses jump and then we won't need the if statement about negative velocity
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Platform")
        {
            //Debug.Log("Land!");
            inAir = false;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Platform")
        {
            //Debug.Log("Jump!");
            inAir = true;
        }
    }
}
