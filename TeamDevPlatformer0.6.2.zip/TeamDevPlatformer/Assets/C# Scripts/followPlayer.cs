﻿using UnityEngine;

public class followPlayer : MonoBehaviour
{
    public Transform target;
    public float speed = 0.08f;
    Vector3 desiredPosition, position;
    public float offset = -10f;
    //need to convert Vector3 to array to save
    public static float[] savePosition = { 0, 0, 0 };

    void FixedUpdate()
    {
        desiredPosition = new Vector3(target.position.x, target.position.y, offset);
        transform.position = Vector3.Lerp(transform.position, desiredPosition, speed);
        getPosition();
    }

    //get postion sets the savePosition array to pass to PlayerData to save
    void getPosition()
    {
        savePosition[0] = target.position.x;
        savePosition[1] = target.position.y;
        savePosition[2] = target.position.z;
    }

    public void setPosition(float[] loadPosition)
    {
        //Debug.Log(transform.position);
        //Vector3 load;
        //load.x = loadPosition[0];
        //load.y = loadPosition[1];
        //load.z = loadPosition[2];
        //transform.position = load;
    }

}
