﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour
{
    GameObject[] doors;
    public char connection;

    private void Start()
    {
        doors = GameObject.FindGameObjectsWithTag("Door");
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        PlayerBehavior player = collision.gameObject.GetComponent<PlayerBehavior>();

        if (player != null && Input.GetAxis("Vertical") > 0 && player.inAir == false)
        {
            foreach (GameObject door in doors) 
            {
                if (door.GetComponent<Door>().connection == this.gameObject.GetComponent<Door>().connection &&
                    door.GetComponent<Transform>().position != this.gameObject.GetComponent<Transform>().position &&
                    !player.isInvincible)
                {
                    player.InvincibilityOn(1f);
                    player.GetComponent<Transform>().position = door.GetComponent<Transform>().position;
                }
            }
        }
    }
}
