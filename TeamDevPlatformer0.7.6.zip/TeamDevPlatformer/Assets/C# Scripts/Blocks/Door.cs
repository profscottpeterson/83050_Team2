﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour
{
    GameObject[] doors;
    public char connection;
    public GameObject doorPrompt;

    private GameObject instaniatedDoorPrompt;

    private void Start()
    {
        // Grabs all the doors in the Scene
        doors = GameObject.FindGameObjectsWithTag("Door");

        // Creates the door prompt above the door
        instaniatedDoorPrompt = Instantiate(doorPrompt, new Vector3(gameObject.transform.position.x, gameObject.transform.position.y + 2, gameObject.transform.position.z), Quaternion.identity);
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        // Player Reference
        PlayerBehavior player = collision.gameObject.GetComponent<PlayerBehavior>();

        // If the player is in front of the door, presses 'W', and isn't in the air
        if (player != null && Input.GetAxis("Vertical") > 0 && player.inAir == false)
        {
            // Loop through the doors array
            foreach (GameObject door in doors) 
            {
                // Find the other matching door based on connection
                if (door.GetComponent<Door>().connection == this.gameObject.GetComponent<Door>().connection &&
                    door.GetComponent<Transform>().position != this.gameObject.GetComponent<Transform>().position &&
                    !player.isInvincible)
                {
                    // Make player invincible
                    player.InvincibilityOn(1f);

                    // Move player to the other door
                    player.GetComponent<Transform>().position = door.GetComponent<Transform>().position;
                }
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Player Reference
        PlayerBehavior player = collision.gameObject.GetComponent<PlayerBehavior>();

        // If the player is standing in front of a door
        if (player != null)
        {
            // Show the prompt
            instaniatedDoorPrompt.GetComponent<Renderer>().enabled = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        // Player Reference
        PlayerBehavior player = collision.gameObject.GetComponent<PlayerBehavior>();

        // If the player is standing in front of a door
        if (player != null)
        {
            // Hide the prompt
            instaniatedDoorPrompt.GetComponent<Renderer>().enabled = false;
        }
    }

}
