﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pickup : MonoBehaviour
{
    PlayerBehavior player;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        var collider = collision.gameObject;
        if (collider.CompareTag("Player"))
        {
            player = collider.GetComponent<PlayerBehavior>();
            if (player.currentHealth < player.maxHealth)
            {
                Destroy(this.gameObject);
                player.ChangeHealth(1);
            }
        }
    }
}
