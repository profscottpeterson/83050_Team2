﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBehavior : MonoBehaviour
{
    // Enemy Kill spot
    public CapsuleCollider2D killSpot;

    // Alive check because the Player was technically killing the same enemy twice
    private bool alive = true;

    Rigidbody2D rbPlayer;
    Transform tr;

    // Player Detection
    public CapsuleCollider2D detectionRange;
    public bool seesPlayer;
    public Transform target;
    public float speed = 0.08f;
    Vector3 desiredPosition, position;
    
    private void Start()
    {
        seesPlayer = false;
    }

    void FixedUpdate()
    {
        if (seesPlayer)
        {
            desiredPosition = new Vector3(target.position.x, target.position.y, 0f);
            transform.position = Vector3.Lerp(transform.position, desiredPosition, speed);
        }
    }

    // Trigger for collider
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            PlayerBehavior player = collision.gameObject.GetComponent<PlayerBehavior>();

            // Player kills
            if (player.footTrigger.IsTouching(this.gameObject.GetComponent<CircleCollider2D>())
                || player.footTrigger.IsTouching(this.gameObject.GetComponent<CapsuleCollider2D>()))
            {
                // If the player's footTrigger hits the enemy
                if (player != null && alive == true)
                {
                    UIElements.instance.UpdateScore(50);

                    player.jumping = true;
                    alive = false;

                    tr = GetComponent<Transform>();
                    tr.position -= new Vector3(0, 0.5f, 0);
                    tr.localScale -= new Vector3(0, 1, 0);
                    CircleCollider2D box = GetComponent<CircleCollider2D>();
                    Destroy(box);
                    Destroy(this);
                }
            }
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        // Sees Player
        if (detectionRange.IsTouching(collision))
        {
            if (collision.gameObject.CompareTag("Player"))
            {
                target = collision.gameObject.GetComponent<Transform>();
                seesPlayer = true;
            }
        }
    }

    // Player out of range
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            seesPlayer = false;
        }
    }
}
