﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FallDeletion : MonoBehaviour
{
    Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.velocity = new Vector3(Random.Range(-0.4f, 0.4f), Random.Range(-0.4f, 0.4f), 0f);
    }

    void Update()
    {
        if (transform.position.y < -50)
            Destroy(this.gameObject);
    }
}
