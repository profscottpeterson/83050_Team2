﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerData {

    //from UIElements float totalTime
    public float time;
    //from PlayerMovement class, int currenthealth
    public int health;
    public float[] position;
    public int score;
    //need to pass the UIElements object to this class
    public static UIElements main = new UIElements();
    public static int loadHealth = 10;
    public static float loadTotalTime;
    public static int loadScore;
    public static GameObject[] enemies = GameObject.FindGameObjectsWithTag("Damage");
    public List<float[]> enemyList = new List<float[]>();

    public PlayerData(UIElements ui)
    {
        foreach (GameObject g in enemies)
        {
            if (g != null)
            {
                float[] temp = { 0, 0 };
                temp[0] = g.transform.position.x;
                temp[1] = g.transform.position.y;
                enemyList.Add(temp);
            }
        }
        PlayerData.main = ui;
        health = ui.health;
        //time = ui.totalTime;
        time = ui.currentTime;
        score = int.Parse(ui.uiScore.text);
        position = PlayerBehavior.savePosition;
    }

    public static void updateHealth(int health)
    {
        loadHealth = health;
    }

    public static UIElements getPlayer(){
        return main;
    }

    public static void setPlayer(PlayerData load) {

        loadHealth = load.health;
        loadTotalTime = load.time;
        loadScore = load.score;

        PlayerBehavior behavior = new PlayerBehavior();
        behavior.setPosition(load.position);

        Debug.Log("SetPlayer Health: " + loadHealth);
        Debug.Log("SetPlayer Time: " + loadTotalTime);
        Debug.Log("SetPlayer Score: " + loadScore);
        Debug.Log("SetPosition: x = " + load.position[0] + ", y = " + load.position[1]);
    }

    public static void setEnemies(PlayerData loadEnemies)
    {
        int x = 0;
        foreach (GameObject g in enemies)
        {
            if (g != null && x < loadEnemies.enemyList.Count)
            {
                Vector2 pos;
                pos.x = loadEnemies.enemyList[x][0];
                pos.y = loadEnemies.enemyList[x][1];
                g.transform.position = pos;
            }
            x++;
        }

    }
}
