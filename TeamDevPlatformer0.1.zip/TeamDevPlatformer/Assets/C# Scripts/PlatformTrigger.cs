﻿using UnityEngine;

public class PlatformTrigger : MonoBehaviour
{
    void OnTriggerEnter2D(Collider col)
    {
        
    }
}
