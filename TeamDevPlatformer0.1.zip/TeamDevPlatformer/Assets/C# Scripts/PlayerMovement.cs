﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float currentSpeed;
    public float runSpeed = 0.08f;
    public float jumpSpeed = 10f;
    
    float hMove = 0f;
    bool jumping = false;
    float jumphMove;
    public bool inAir = false;

    Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        hMove = Input.GetAxis("Horizontal");
        if (Input.GetAxis("Jump") > 0 && !inAir)
        {
            // jumping is when the player is obtaining upward velocity
            // inAir is when the player is not on the ground
            jumping = true;
        }
    }

    void FixedUpdate()
    {

        if (jumping)
        {
            rb.velocity = new Vector2(hMove * 15f, jumpSpeed);
            jumping = false;
            jumphMove = hMove;
        }
        else if (inAir)
        {
            if (Mathf.Abs(jumphMove - hMove) > 0.3)
            {
                rb.velocity = new Vector2(hMove * runSpeed * 0.7f, rb.velocity.y);
            }
            else
            {
                rb.velocity = new Vector2(hMove * runSpeed * 1.2f, rb.velocity.y);
            }
        }
        else if (!inAir)
        {
            // Mathf.Clamp(n1, n2, n3)
            rb.velocity = new Vector2(hMove * runSpeed, rb.velocity.y);
        }

        //if (rb.velocity.y < 0)
        //{
        //    inAir = true;
        //}

        //if ((rb.position.x > 8 && rb.velocity.x > 0) || (rb.position.x < -8 && rb.velocity.x < 0))
        //{
        //    rb.velocity = new Vector2(0, rb.velocity.y);
        //}

        currentSpeed = rb.velocity.x;
    }
    
    // Edge Collision is set to trigger and is on the bottom of the player so the edge collision will fire off the trigger events when the platform class touches it
    // Using the Enter and Exit methods, I got rid of setting the inAir bool to false when someone presses jump and then we won't need the if statement about negative velocity
    // We can use these events for other things too like bouncing off enemies, unless you want to use OnCollsionEnter2D for that
    private void OnTriggerEnter2D(Collider2D collision)
    {
        PlatformTrigger platform = collision.gameObject.GetComponent<PlatformTrigger>();

        if (platform != null)
        {
            //Debug.Log("Land!");
            inAir = false;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        PlatformTrigger platform = collision.gameObject.GetComponent<PlatformTrigger>();

        if (platform != null)
        {
            //Debug.Log("Jump!");
            inAir = true;
        }
    }
}
