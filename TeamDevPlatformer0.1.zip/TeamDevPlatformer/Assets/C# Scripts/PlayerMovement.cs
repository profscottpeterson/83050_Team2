﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public EdgeCollider2D ec;
    public float currentSpeed;
    public float runSpeed = 0.08f;
    public float jumpSpeed = 10f;
    float hMove = 0f;
    bool jumping = false;
    float jumphMove;
    public bool inAir = false;
    Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        ec = GetComponent<EdgeCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {
        hMove = Input.GetAxis("Horizontal");
        if (Input.GetAxis("Jump") > 0 && !inAir)
        {
            // jumping is when the player is obtaining upward velocity
            // inAir is when the player is not on the ground
            jumping = true;
            inAir = true;
        }
    }

    void FixedUpdate()
    {

        if (jumping)
        {
            rb.velocity = new Vector2(hMove * 15f, jumpSpeed);
            jumping = false;
            jumphMove = hMove;
        }
        else if (inAir)
        {
            if (Mathf.Abs(jumphMove - hMove) > 0.3)
            {
                rb.velocity = new Vector2(hMove * runSpeed * 0.7f, rb.velocity.y);
            }
            else
            {
                rb.velocity = new Vector2(hMove * runSpeed * 1.1f, rb.velocity.y);
            }
        }
        else if (!inAir)
        {
            // Mathf.Clamp(n1, n2, n3)
            rb.velocity = new Vector2(hMove * runSpeed, rb.velocity.y);
        }

        if (rb.velocity.y < 0)
        {
            inAir = true;
        }

        //if ((rb.position.x > 8 && rb.velocity.x > 0) || (rb.position.x < -8 && rb.velocity.x < 0))
        //{
        //    rb.velocity = new Vector2(0, rb.velocity.y);
        //}

        currentSpeed = rb.velocity.x;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        // Trying to collide with only the top of the platforms
        if (collision.gameObject == ec)
        {
            inAir = false;
        }
    }
}
