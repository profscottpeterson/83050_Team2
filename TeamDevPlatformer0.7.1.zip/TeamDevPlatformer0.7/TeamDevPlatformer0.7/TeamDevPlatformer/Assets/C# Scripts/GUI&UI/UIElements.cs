﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIElements : MonoBehaviour
{
    public static UIElements instance { get; private set; }
    public Text uiHealth;
    public Text uiTimer;
    public Text uiScore;
    public float totalTime;
    //used to send health to PlayerData class
    public int health;

    public float currentTime;
    void Awake()
    {
        instance = this;

        totalTime = 300.0f;
        currentTime = totalTime;
        uiTimer.text = totalTime.ToString();
    }

    public void UpdateHealth(int value)
    {
        health = value;
        PlayerData.updateHealth(value);
        uiHealth.text = value.ToString();
        if (health == 0) { gameOver(); }
    }

    public void UpdateScore(int value)
    {
        uiScore.text = (int.Parse(uiScore.text) + value).ToString();
    }

    public void IncrementTime()
    {
        if (int.Parse(uiTimer.text) == 0) { gameOver(); }

        currentTime = currentTime - Time.deltaTime;

        uiTimer.text = Mathf.Round(currentTime).ToString();
    }
    
    public string CalculateTime()
    {
        int timeLeft = int.Parse(uiTimer.text);
        
        int timeToComplete = (int)totalTime - timeLeft;

        return timeToComplete.ToString();
    }

    //Start pause methods
    GameObject[] pauseObjects;

    // Use this for initialization
    public void Start()
    {
        Time.timeScale = 1;
        pauseObjects = GameObject.FindGameObjectsWithTag("ShowOnPause");
        hidePaused();
    }

    // Update is called once per frame
    public void Update()
    {
        //uses the p button to pause and unpause the game
        if (Input.GetKeyDown(KeyCode.P))
        {
            if (Time.timeScale == 1)
            {
                Time.timeScale = 0;
                showPaused();
            }
            else
            {
                Time.timeScale = 1;
                hidePaused();
            }
        }

    }

    //shows objects with ShowOnPause tag
    public void showPaused()
    {
        foreach (GameObject g in pauseObjects)
        {
            g.SetActive(true);
        }
        PlayerData updateInfo = new PlayerData(this);
    }

    //hides objects with ShowOnPause tag
    public void hidePaused()
    {
        foreach (GameObject g in pauseObjects)
        {
            g.SetActive(false);
        }
    }

    //needed to refresh total time after game is loaded
    public void load()
    {
        //totalTime = PlayerData.loadTotalTime;
        currentTime = PlayerData.loadTotalTime;
        Debug.Log("PlayerData loadTotalTime: " + PlayerData.loadTotalTime);
        uiHealth.text = PlayerData.loadHealth.ToString();
        uiScore.text = PlayerData.loadScore.ToString();
        Debug.Log("PlayerData loadScore: " + PlayerData.loadScore.ToString());
        UpdateScore(0);
    }

    //public void destroyObjects(GameObject[] gObjects)
    //{
    //    foreach (GameObject g in gObjects)
    //    {
    //        Destroy(g);
    //    }
    //}

    public void gameOver()
    {
        Canvas endUI;
        Text end;
        GameObject temp = GameObject.Find("LevelEndUI");
        endUI = temp.GetComponent<Canvas>();
        temp = GameObject.Find("Congrats");
        temp.SetActive(false);
        temp = GameObject.Find("seconds");
        temp.SetActive(false);
        temp = GameObject.Find("You beat....");
        temp.SetActive(false);
        temp = GameObject.Find("txtTimeRemaining");
        temp.SetActive(false);
        temp = GameObject.Find("LevelEndUI/Mask/txtScore");
        temp.SetActive(false);
        temp = GameObject.Find("LevelEndUI/Mask/ScoreLabel");
        end = temp.GetComponent<Text>();
        end.text = "Game Over";
        endUI.enabled = true;
        Time.timeScale = 0;
    }

}