﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnBlock : MonoBehaviour
{
    public PlayerBehavior player;
    public GameObject playerGameObject;

    private GameObject p;

    private void Awake()
    {
        // Make the Player spawner invisible
        gameObject.GetComponent<Renderer>().enabled = false;

        // If player isn't specified
        if (player != null)
        {
            // Move the player to the spawn block location
            player.transform.position = gameObject.transform.position;
        }
        else
        {
            // TODO: Get the camera to follow the player when created through code
            p = Instantiate(playerGameObject, gameObject.transform.position, Quaternion.identity);

            // If there isn't UI
            if (!FindObjectOfType<UIElements>())
            {
                // Set the player object to not have UI
                p.GetComponent<PlayerBehavior>().isThereUI = false;
                
                // Disable the EditorGUI
                p.GetComponent<EditorGUI>().enabled = false;
            }
        }
    }
}
