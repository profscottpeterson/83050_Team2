﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBehavior : MonoBehaviour
{
    public float currentSpeed;
    public float runSpeed = 8f;
    public float jumpSpeed = 10f;
    public bool inAir = true; // Change this if we spawn the player on the ground
    public int maxHealth = 10;
    public int currentHealth;
    public float timeInvincible = 3.0f;
    public EdgeCollider2D footTrigger;
    public EdgeCollider2D headTrigger;
    public GameObject enemyPrefab;
    public GameObject healthDropPrefab;
    public GameObject brickPiecePrefab;

    float hMove = 0f;
    public bool jumping = false;
    float jumphMove;
    bool isInvincible;
    float invincibleTimer;
    
    Rigidbody2D rb;
    Transform playerTransform;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        playerTransform = GetComponent<Transform>();

        // Set health
        currentHealth = maxHealth;
        UIElements.instance.UpdateHealth(currentHealth);
    }

    // Update is called once per frame
    void Update()
    {
        hMove = Input.GetAxis("Horizontal");
        if (Input.GetAxis("Jump") > 0 && !inAir)
        {
            // jumping is when the player is obtaining upward velocity
            // inAir is when the player is not on the ground
            jumping = true;
        }

        //update health from PlayerData, as it's static there.
        currentHealth = PlayerData.loadHealth;

    }

    void FixedUpdate()
    {
        if (jumping)
        {
            rb.velocity = new Vector2(hMove * 15f, jumpSpeed);
            jumping = false;
            jumphMove = hMove;
        }
        else if (inAir)
        {
            if (Mathf.Abs(jumphMove - hMove) > 0.3)
            {
                rb.velocity = new Vector2(hMove * runSpeed * 0.7f, rb.velocity.y);
            }
            else
            {
                rb.velocity = new Vector2(hMove * runSpeed * 1.2f, rb.velocity.y);
            }
        }
        else if (!inAir)
        {
            // Mathf.Clamp(n1, n2, n3)
            rb.velocity = new Vector2(hMove * runSpeed, rb.velocity.y);
        }

        // Invincibility
        if (isInvincible)
        {
            // Visibly show invincibilty
            gameObject.GetComponent<Renderer>().enabled = !gameObject.GetComponent<Renderer>().enabled;

            // Minus invincible timer
            invincibleTimer -= Time.deltaTime;

            // When Invincibility is done
            if (invincibleTimer < 0)
            {
                // Disable invincibility
                isInvincible = false;

                // Make sure the character is visible
                gameObject.GetComponent<Renderer>().enabled = true;
            }
        }

        currentSpeed = rb.velocity.x;

        // Decrement the game timer
        UIElements.instance.IncrementTime();
    }

    // Update Health Method
    public void ChangeHealth(int amount)
    {
        // If damaged
        if (amount < 0)
        {
            // If invincible then leave method
            if (isInvincible)
            {
                return;
            }

            // Turn invincible on
            isInvincible = true;
            invincibleTimer = timeInvincible;
        }
        
        // Update current health
        currentHealth = Mathf.Clamp(currentHealth + amount, 0, maxHealth);
        
        // Check to see if player is still alive
        if(currentHealth > 0)
        {
            //Debug.Log(currentHealth + "/" + maxHealth);
            UIElements.instance.UpdateHealth(currentHealth);
        }
        else
        {
            Debug.Log("Game Over!");
            UIElements.instance.UpdateHealth(currentHealth);
        }
        
       
    }

    // Edge Collision is set to trigger and is on the bottom of the player so the edge collision will fire off the trigger events when the platform class touches it
    // Using the Stay and Exit methods, I got rid of setting the inAir bool to false when someone presses jump and then we won't need the if statement about negative velocity
    private void OnTriggerStay2D(Collider2D collision)
    {
        // Touching the ground
        if (collision != null && footTrigger.IsTouchingLayers())
        {
            if (!collision.isTrigger)
                inAir = false;
        }

        // Head trigger is touching a something
        if (headTrigger.IsTouchingLayers())
        {
            // Get collider's transform
            Transform blockTransform;
            blockTransform = collision.gameObject.GetComponent<Transform>();

            // A breakable block
            if (collision.gameObject.CompareTag("Break"))
            {
                // Individual bricks to fall
                for (int index = 0; index < 5; index++)
                {
                    Instantiate(brickPiecePrefab, 
                        blockTransform.position + new Vector3(Random.Range(-0.6f, 0.6f), Random.Range(-0.6f, 0.6f), 0f), 
                        Quaternion.Euler(0f, 0f, Random.Range(0.0f, 360.0f)));
                }

                Destroy(collision.gameObject);
            }

            // A mystery block
            if (collision.gameObject.CompareTag("Mystery"))
            {
                // Generate a random 0-2 int
                int rand;
                rand = Random.Range(0, 3);

                SpriteRenderer blockRenderer;
                blockRenderer = collision.gameObject.GetComponent<SpriteRenderer>();

                // Only fire if the block hasn't been used
                if (blockRenderer.color != Color.gray)
                {
                    if (rand == 0)
                    {
                        // Enemy pops out
                        var enemy = Instantiate(enemyPrefab, blockTransform.position + new Vector3(0, 1, 0), Quaternion.identity);
                    }
                    else if (rand == 1)
                    {
                        // Health pops out
                        Instantiate(healthDropPrefab, blockTransform.position + new Vector3(0, 1, 0), Quaternion.identity);
                    }
                    else
                    {
                        // Score increase pops out
                        Debug.Log("Score");
                    }

                    blockRenderer.color = Color.gray;
                }
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        // Leaving the ground
        inAir = true;
    }

    // When the player is touching a damaging object
    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Damage"))
        {
            ChangeHealth(-1);
        }
    }

}
