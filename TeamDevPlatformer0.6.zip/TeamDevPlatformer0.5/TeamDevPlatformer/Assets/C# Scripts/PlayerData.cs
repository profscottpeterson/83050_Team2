﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerData {

    //from UIElements float totalTime
    public float time;
    //from PlayerMovement class, int currenthealth
    public int health;
    public float[] position;
    //need to pass the UIElements object to this class
    public static UIElements main = new UIElements();
    public static int loadHealth = 10;
    public static float loadTotalTime;

    public PlayerData(UIElements ui)
    {
        PlayerData.main = ui;
        health = ui.health;
        time = ui.totalTime;
        position = followPlayer.savePosition;
    }

    public static void updateHealth(int health)
    {
        loadHealth = health;
    }

    public static UIElements getPlayer(){
        return main;
    }

    public static void setPlayer(PlayerData load) {

        loadHealth = load.health;
        loadTotalTime = load.time;

        followPlayer follow = new followPlayer();
        follow.setPosition(load.position);

        Debug.Log("SetPlayer Health: " + loadHealth);
        Debug.Log("SetPlayer Time: " + loadTotalTime);
        Debug.Log("SetPosition: x = " + load.position[0] + ", y = " + load.position[1] + ", z = " + load.position[2]);
    }

}
