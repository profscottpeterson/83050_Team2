﻿using UnityEngine;

public class EditorGUI : MonoBehaviour
{
    private Rect windowRect = new Rect(20, 20, 800, 95);
    public Texture2D imageHealth;
    public Texture2D imageBrick;
    public Texture2D imageMystery;
    public Texture2D imageSpring;
    public Texture2D imageEnemy;
    public Object brickPrefab;
    public Object healthPrefab;
    public Object mysteryPrefab;
    public Object springPrefab;
    public Object enemyPrefab;
    Vector3 playerPos;
    public bool toggleAI = true;
    
    void OnGUI()
    {
        playerPos = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>().position;
        windowRect = GUI.Window(0, windowRect, DoMyWindow, "Editor Menu");
    }

    // Make the contents of the window
    void DoMyWindow(int windowID)
    {
        if (GUI.Button(new Rect(10, 20, 100, 60), imageHealth))
        {
            InstantiateObject(healthPrefab);
        }
        if (GUI.Button(new Rect(110, 20, 100, 60), imageBrick))
        {
            InstantiateObject(brickPrefab);
        }
        if (GUI.Button(new Rect(210, 20, 100, 60), imageMystery))
        {
            InstantiateObject(mysteryPrefab);
        }
        if (GUI.Button(new Rect(310, 20, 100, 60), imageSpring))
        {
            InstantiateObject(springPrefab);
        }
        if (GUI.Button(new Rect(410, 20, 100, 60), imageEnemy))
        {
            InstantiateObject(enemyPrefab);
        }

        toggleAI = GUI.Toggle(new Rect(510, 20, 60, 60), toggleAI, "Enemy AI");
       
        GUI.DragWindow(new Rect(0, 0, 10000, 20));
    }

    private void FixedUpdate()
    {
        if (toggleAI)
        {
            foreach (GameObject g in GameObject.FindGameObjectsWithTag("Damage"))
            {
                if (!g.name.Contains("Variant") && g.name.Contains("Enemy"))
                    g.GetComponent<EnemyBehavior>().seesPlayer = false;
            }
        }
    }

    public void InstantiateObject(Object prefab)
    {
        Instantiate(prefab, new Vector3(Mathf.Round(playerPos.x), Mathf.Round(playerPos.y) + 1.6f, 0f), Quaternion.identity);
    }
}