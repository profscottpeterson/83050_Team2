﻿using UnityEngine;

public class Draggable : MonoBehaviour
{
    private Vector2 mousePosition;
    private float deltaX, deltaY;
    private bool missingFloating;
    private Floating floatingScript;
    private bool editorModeOn;

    private void Start()
    {
        editorModeOn = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerBehavior>().editorModeOn;
    }

    public void OnMouseDown()
    {
        if (editorModeOn)
        {
            if (!missingFloating && gameObject.GetComponent<Floating>())
            {
                floatingScript = gameObject.GetComponent<Floating>();
                Destroy(floatingScript);
                missingFloating = true;
            }

            deltaX = Camera.main.ScreenToWorldPoint(Input.mousePosition).x - transform.position.x;
            deltaY = Camera.main.ScreenToWorldPoint(Input.mousePosition).y - transform.position.y;
        }
    }

    private void OnMouseDrag()
    {
        if (editorModeOn)
        {
            mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            transform.position = new Vector2(mousePosition.x - deltaX, mousePosition.y - deltaY);
        }
    }

    private void OnMouseUp()
    {
        if (editorModeOn)
        {
            // Object is released
            // Snap to grid
            transform.position = new Vector3(Mathf.Round(mousePosition.x - deltaX), Mathf.Round(mousePosition.y - deltaY), 1);
            if (missingFloating)
            {
                gameObject.AddComponent<Floating>();
                missingFloating = false;
            }
        }
    }
}
